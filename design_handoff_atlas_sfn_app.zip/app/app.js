/* Atlas SfN — couche application (installation, mobile, hors ligne, GPS) */
(function(){
const A = window.ATLAS, map = A.map;
const $ = s => document.querySelector(s);
const toast = (t, ms=2600) => { const e=$('#toast'); e.textContent=t; e.classList.add('on'); clearTimeout(toast._t); toast._t=setTimeout(()=>e.classList.remove('on'),ms); };
const isMobile = () => matchMedia('(max-width:820px)').matches;
const standalone = matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: window-controls-overlay)').matches || navigator.standalone;

/* ---------- Service worker (hors ligne) ---------- */
if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  navigator.serviceWorker.register('sw.js').catch(()=>{});
}

/* ---------- Installation (Samsung Internet / Chrome Android / Chrome-Edge ordinateur) ---------- */
let deferred = null;
const bI = $('#bInstall');
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; bI.hidden = false; });
window.addEventListener('appinstalled', () => { bI.hidden = true; deferred = null; toast('Atlas installé ✓ — retrouvez-le sur votre écran d\'accueil / bureau'); });
const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
if (!standalone) bI.hidden = false; // toujours proposé ; repli sur instructions si pas d'invite native
bI.onclick = async () => {
  if (deferred) { deferred.prompt(); const r = await deferred.userChoice; if (r.outcome==='accepted') bI.hidden = true; deferred = null; return; }
  const ua = navigator.userAgent;
  let txt;
  if (/SamsungBrowser/i.test(ua)) txt = 'Dans Samsung Internet : touchez le menu <b>≡</b> en bas à droite, puis <b>« Ajouter la page à » → « Écran d\'accueil »</b>. L\'atlas s\'ouvrira ensuite comme une application, en plein écran.';
  else if (/Android/i.test(ua)) txt = 'Dans Chrome : touchez le menu <b>⋮</b> en haut à droite, puis <b>« Installer l\'application »</b> (ou « Ajouter à l\'écran d\'accueil »).';
  else if (ios) txt = 'Dans Safari : touchez <b>Partager</b> puis <b>« Sur l\'écran d\'accueil »</b>.';
  else txt = 'Sur ordinateur, ouvrez l\'atlas dans <b>Chrome</b> ou <b>Edge</b> : cliquez sur l\'icône <b>⊕ Installer</b> à droite de la barre d\'adresse (ou menu ⋮ → « Installer Atlas SfN »). L\'atlas s\'ouvre alors dans sa propre fenêtre, avec une icône sur le bureau et dans la barre des tâches.';
  $('#iostxt').innerHTML = txt; $('#iosdlg').classList.add('on');
};

/* ---------- Réseau ---------- */
const net = () => { const n=$('#netst'); n.textContent = navigator.onLine ? (standalone?'APP · EN LIGNE':'EN LIGNE') : 'HORS LIGNE'; n.classList.toggle('off', !navigator.onLine); };
addEventListener('online', net); addEventListener('offline', () => { net(); toast('Hors ligne — les données et le fond de carte déjà chargés restent disponibles'); }); net();

/* ---------- Préchargement du fond de carte pour le terrain ---------- */
function tilesFor(lat, lon, z, d){
  const t=(la,lo)=>{const n=2**z; const x=Math.floor((lo+180)/360*n); const r=la*Math.PI/180; const y=Math.floor((1-Math.log(Math.tan(r)+1/Math.cos(r))/Math.PI)/2*n); return [x,y];};
  const [x0,y0]=t(lat+d,lon-d), [x1,y1]=t(lat-d,lon+d), out=[];
  for(let x=x0;x<=x1;x++) for(let y=y0;y<=y1;y++) out.push([z,x,y]); return out;
}
$('#bOffline').onclick = async () => {
  if (!navigator.onLine) return toast('Connectez-vous pour précharger le fond de carte');
  const urls = new Set();
  // vue d'ensemble
  for (let z=9; z<=12; z++) tilesFor(14.80,-17.10,z,0.35).forEach(([z,x,y])=>urls.add(`https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`));
  // autour de chaque site
  window.ATLAS_SITES.forEach(s => { for (let z=13; z<=17; z++) tilesFor(s.pos[0], s.pos[1], z, z<16?0.012:0.005).forEach(([z,x,y])=>{
    urls.add(`https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`);
    urls.add(`https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/${z}/${y}/${x}`);
  }); });
  const list=[...urls]; let done=0; const b=$('#bOffline'); b.disabled=true;
  const cache = 'caches' in window ? await caches.open('atlas-tiles-v1') : null;
  const work = async () => { while (list.length) { const u=list.pop();
    try { if (cache && !(await cache.match(u))) { const r = await fetch(u, {mode:'no-cors'}); await cache.put(u, r); } } catch(_){}
    done++; if (done%20===0) b.textContent = `Hors ligne ${Math.round(done/urls.size*100)} %`; } };
  await Promise.all(Array.from({length:6}, work));
  b.disabled=false; b.textContent='Hors ligne ✓';
  toast(`${urls.size} tuiles satellite enregistrées : les 15 sites restent consultables sans réseau`, 3600);
};

/* ---------- GPS : ma position sur le terrain ---------- */
let me=null, watch=null;
$('#bLocate').onclick = () => {
  const b=$('#bLocate');
  if (watch!==null) { navigator.geolocation.clearWatch(watch); watch=null; if(me){map.removeLayer(me); me=null;} b.classList.remove('on'); return; }
  if (!navigator.geolocation) return toast('Géolocalisation non disponible');
  b.classList.add('on'); let first=true;
  watch = navigator.geolocation.watchPosition(p => {
    const ll=[p.coords.latitude,p.coords.longitude];
    if(!me){ me=L.layerGroup().addTo(map); }
    me.clearLayers();
    L.circle(ll,{radius:p.coords.accuracy,color:'#2a7de1',weight:1,fillOpacity:.12}).addTo(me);
    L.marker(ll,{icon:L.divIcon({className:'',html:'<div class="mepos"></div>',iconSize:[16,16],iconAnchor:[8,8]}),zIndexOffset:2000}).addTo(me)
      .bindTooltip(`Ma position<br>${ll[0].toFixed(6)}° N · ${(-ll[1]).toFixed(6)}° O<br>± ${Math.round(p.coords.accuracy)} m`);
    // site le plus proche
    let best=null; window.ATLAS_SITES.forEach(s=>{const d=A.dist(ll,s.pos); if(!best||d<best.d) best={s,d};});
    if (first) { first=false; map.flyTo(ll, Math.max(map.getZoom(),15), {duration:.8});
      if(best) toast(`Site le plus proche : ${best.s.id} · ${best.s.nom} — ${best.d<1000?Math.round(best.d)+' m':(best.d/1000).toFixed(1)+' km'}`, 4000); }
  }, e => { toast('Position refusée ou indisponible'); b.classList.remove('on'); watch=null; }, {enableHighAccuracy:true, maximumAge:5000});
};

/* ---------- Panneau glissant (téléphone) ---------- */
const sh=$('#sheet');
const setState = st => { sh.classList.remove('half','full'); if (st) sh.classList.add(st); setTimeout(()=>map.invalidateSize(), 340); };
const cycle = () => setState(sh.classList.contains('full') ? '' : sh.classList.contains('half') ? 'full' : 'half');
let y0=null, t0=0, base=0, moved=false;
const startDrag = e => { if(!isMobile() || e.target.closest('button')) return; y0=(e.touches?e.touches[0]:e).clientY; t0=Date.now(); moved=false;
  base = sh.getBoundingClientRect().top; sh.classList.add('dragging'); };
const moveDrag = e => { if(y0===null) return; const y=(e.touches?e.touches[0]:e).clientY; const dy=y-y0; if(Math.abs(dy)>4) moved=true;
  const top=Math.max(sh.parentElement.clientHeight - sh.offsetHeight, base+dy) - (sh.parentElement.clientHeight - sh.offsetHeight);
  sh.style.transform=`translateY(${top}px)`; if(e.cancelable) e.preventDefault(); };
const endDrag = e => { if(y0===null) return; sh.classList.remove('dragging'); sh.style.transform='';
  const y=(e.changedTouches?e.changedTouches[0]:e).clientY, dy=y-y0, v=dy/Math.max(1,Date.now()-t0); y0=null;
  if(!moved){ cycle(); return; }
  const H=sh.offsetHeight, cur=sh.getBoundingClientRect().top - (sh.parentElement.clientHeight - H);
  if (v<-0.5) return setState(sh.classList.contains('half')||sh.classList.contains('full')?'full':'half');
  if (v> 0.5) return setState(sh.classList.contains('full')?'half':'');
  const r = (cur+dy)/H; setState(r<0.25?'full':r<0.7?'half':''); };
['#grip','.brand'].forEach(s=>{ const el=$(s); el.addEventListener('touchstart',startDrag,{passive:true}); el.addEventListener('mousedown',startDrag); });
addEventListener('touchmove',moveDrag,{passive:false}); addEventListener('mousemove',moveDrag);
addEventListener('touchend',endDrag); addEventListener('mouseup',endDrag);
// les onglets ouvrent le panneau
document.querySelectorAll('#tabs button').forEach(b=>b.addEventListener('click',()=>{ if(isMobile() && !sh.classList.contains('full') && !sh.classList.contains('half')) setState('half'); }));
// la sélection d'un site (carte ou liste) ouvre la fiche à mi-hauteur
const sel = A.select;
A.select = id => { sel(id); if (isMobile()) { setState('half'); const p=$('#p-sites'); if(p) p.scrollTop=0; } };
Object.values(A.markers||{}).forEach(m=>{ m.off('click'); m.on('click',e=>{ const id=+Object.keys(A.markers).find(k=>A.markers[k]===m); A.select(id); }); });

/* ---------- Raccourcis ?tab=… ---------- */
const q=new URLSearchParams(location.search).get('tab');
if (q) { const b=document.querySelector(`#tabs button[data-t="${q}"]`); if(b) b.click(); }

addEventListener('resize', ()=>map.invalidateSize());
setTimeout(()=>map.invalidateSize(), 300);
})();
